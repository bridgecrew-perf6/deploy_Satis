
<?php $__env->startSection('content'); ?>
          <nav class="navbar" >
            <div class="brand-title">TALLER DE INGENIERIA DE SOFTWARE</div>
            <a href="#" class="toggle-button">
              <span class="bar"></span>
              <span class="bar"></span>
              <span class="bar"></span>
            </a>
            <div class="navbar-links">
              <ul>
                <li><a href="<?php echo e(route('estudiante.inicioE')); ?>">Inicio</a></li>
                <li><a href="<?php echo e(route('estudiante.empresa')); ?>">Empresa</a></li>
                <li><a href="<?php echo e(route('estudiante.documentosB')); ?>">Documentos base</a></li>
                <li><a href="<?php echo e(url('/estudiante/lista')); ?>">Lista de empresas</a></li>
                <li><a href="<?php echo e(route('fundaempresa')); ?>">Registrar funda empresa TIS</a></li>
                <li><a href="<?php echo e(route('auth.logout')); ?>">Cerrar sesion</a></li>
            
          </ul>
        </div>
      </nav>
      <?php $__env->stopSection(); ?>
    
      <?php $__env->startSection('cuerpo'); ?>
      <section>
        
        <div class="mt-5 mb-5 ">
          <div class=" row d-flex justify-content-between cards ">
            <div class="col-sm-6 avisotes">
              <h2 class="align-items-center avisos text-light">
                Publicacion de convocatoria TIS
              </h2>
              <div class="card ">
                <?php $__currentLoopData = $convocatorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $convocatorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <h5 class="card-title text-ligth"><?php echo e($convocatorias->name); ?></h5>
                  
                  <p class="card-text">link documento:
                  <a class="" href="https://drive.google.com/file/d/1Kpy9tuMYdj1oB15c8nPVqKenT2fMZ2XX/view?usp=sharing"><?php echo e($convocatorias->nombre); ?></a></p>
                  <p class="card-text">codigo: <?php echo e($convocatorias->codigo); ?></p>
                  <p class="card-text">Gestion: <?php echo e($convocatorias->gestion); ?></p>
                  <p class="card-text">Semestre: <?php echo e($convocatorias->semestre); ?></p> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <div class="card-body">
               
                </div>
              </div>
            </div>
  
            <div class="col-sm-6 avisotes">
              <h2 class="align-items-center avisos text-light">
                Avisos
              </h2>
              <div class="cardazo">
                <?php $__currentLoopData = $avisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avisos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2 class="card-title text-ligth"><?php echo e($avisos->name); ?></h2>
                
                <p class="card-text"><?php echo e($avisos->descripcion); ?></p>
                <p class="card-text">codigo: <?php echo e($avisos->codigo); ?></p>
                <p class="card-text">Gestion: <?php echo e($avisos->gestion); ?></p>
                <p class="card-text">Semestre: <?php echo e($avisos->semestre); ?></p> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                <div class="card-body">

                </div>
              </div>            
            </div>
          </div>
        </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantillaD', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/projects_Laravel/Liontech/resources/views//estudiante/inicioE.blade.php ENDPATH**/ ?>