
<?php $__env->startSection('content'); ?>
          <nav class="navbar " >
            
            <div class="brand-title">TALLER DE INGENIERIA DE SOFTWARE</div>
            <a href="#" class="toggle-button">
              <span class="bar"></span>
              <span class="bar"></span>
              <span class="bar"></span>
            </a>
            <div class="navbar-links">
              
              <ul>
                <li><a href="<?php echo e(route('estudiante.inicioE')); ?>">Inicio</a></li>
                <li><a href="<?php echo e(route('estudiante.empresa')); ?>">Empresa</a></li>
                <li><a href="<?php echo e(route('estudiante.documentosB')); ?>">Documentos base</a></li>
                <li><a href="<?php echo e(url('/estudiante/lista')); ?>">Lista de empresas</a></li>
                
             <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Registrar
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="<?php echo e(route('fundaempresa')); ?>">Registrar funda empresa TIS</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('pagos.index')); ?>">Registrar plan de pagos</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('planTrabajos.create')); ?>">Registrar plan de Trabajo</a></li>
           
          </ul>
        </li>
                <li><a href="<?php echo e(route('auth.logout')); ?>">Cerrar sesion</a></li>
            
          </ul>
        </div>
      </div>
      </nav>
      <?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> <?php echo e($pago->estado_del_proyecto); ?></h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('pagos.index')); ?>" title="Go back"> <i
                        class="fas fa-backward "></i> </a>
            </div>
        </div>
    </div>
    <div class="formPlanT">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Estado del Proyecto:</strong>
                <?php echo e($pago->estado_del_proyecto); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Entregable:</strong>
                <?php echo e($pago->entregable); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Fecha de Entrega:</strong>
                <?php echo e($pago->fecha_de_entrega); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Porcentaje:</strong>
                <?php echo e($pago->porcentaje); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Costo(Bs.):</strong>
                <?php echo e($pago->costo); ?>

            </div>
        </div>
        <!--<div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Date Created:</strong>
                <?php echo e(date_format($pago->created_at, 'jS M Y')); ?>

            </div>
        </div>-->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantillaD', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liontech2\Liontech\resources\views/pagos/show.blade.php ENDPATH**/ ?>