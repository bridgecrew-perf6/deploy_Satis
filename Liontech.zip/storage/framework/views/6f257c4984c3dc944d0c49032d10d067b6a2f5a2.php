<?php $__env->startSection('content'); ?>
          <nav class="navbar" >
            <div class="brand-title">TALLER DE INGENIERIA DE SOFTWARE</div>
            <a href="#" class="toggle-button">
              <span class="bar"></span>
              <span class="bar"></span>
              <span class="bar"></span>
            </a>
            <div class="navbar-links">
              <ul>
                <li><a href="<?php echo e(route('docente.inicioD')); ?>">Inicio</a></li>
                <li><a href="<?php echo e(route('docente.convocatoriasD')); ?>">Agregar convocatoria</a></li>
                <li><a href="<?php echo e(route('docente.avisosD')); ?>">Agregar Avisos</a></li>
                <li><a href="<?php echo e(url('/docente/lista')); ?>">Lista de empresas</a></li>
                <li><a href="<?php echo e(url('/docente/calendario')); ?>">Calendario</a></li>
                <li><a href="<?php echo e(route('auth.register')); ?>">Registrar estudiantes</a></li>
                <li><a href="<?php echo e(route('auth.logout')); ?>">Cerrar sesion</a></li> 
              </ul>
            </div>
          </nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
<section>
  <div class="container mt-5 mb-5 ">
  <div class=" row d-flex justify-content-between cards ">
    <div class="col-sm-6">
      <h2 class="align-items-center avisos text-light">
        Publicacion de convocatoria TIS
      </h2>
      <div class="card ">
      
       


      
       
        <div class="card-body">
        
        </div>
      </div>
    </div>

    <div class="col-sm-5 avisotes">
      <h2 class="align-items-center avisos text-light">
        Avisos
      </h2>



<div class = "cars">
      <div class="cardazo">

        <div class="card-body">
   
     
        </div>
      </div>
     
      </div> 
    </div>
  </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantillaD', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/projects_Laravel/Liontech/resources/views/docente/dashboard.blade.php ENDPATH**/ ?>