<?php $__env->startSection('cuerpo'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Registro Plan de Plan de Trabajo </h2>
            </div>
            <?php if($LoggedUserInfo->tipo==3): ?>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('planTrabajos.create')); ?>" title="Crear un plan de Trabajo"> <i class="fas fa-plus-circle"></i>
                    </a>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered table-responsive-lg">
        <tr>
            <!--<th>No</th>-->
            <th>N° Sprint</th>
            <th>Resultado</th>
            <th>Duración</th>
            <th>Fecha Inicio</th>
            <th>Fecha Fin</th>
            <?php if($LoggedUserInfo->tipo==3): ?>
            <th width="280px">Acción</th>
            <?php endif; ?>
        </tr>
        <?php $__currentLoopData = $planTrabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planTrabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!--<td><?php echo e(++$i); ?></td>-->
                <td><?php echo e($planTrabajo->sprint); ?></td>
                <td><?php echo e($planTrabajo->resultado); ?></td>
                <td><?php echo e($planTrabajo->duración); ?></td>
                <td><?php echo e($planTrabajo->fecha_inicio); ?></td>
                <td><?php echo e($planTrabajo->fecha_fin); ?></td>

                <?php if($LoggedUserInfo->tipo==3): ?>
                <td>

                    <form action="<?php echo e(route('planTrabajos.destroy', $planTrabajo->id)); ?>" method="POST">

                        <a href="<?php echo e(route('planTrabajos.show', $planTrabajo->id)); ?>" title="show">
                            <i class="fas fa-eye text-success  fa-lg"></i>
                        </a>

                        <a href="<?php echo e(route('planTrabajos.edit', $planTrabajo->id)); ?>">
                            <i class="fas fa-edit  fa-lg"></i>

                        </a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit" title="delete" style="border: none; background-color:transparent;">
                            <i class="fas fa-trash fa-lg text-danger"></i>

                        </button>
                    </form>
                </td>
                <?php endif; ?>


            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/projects_Laravel/Liontech/resources/views/planTrabajos/index.blade.php ENDPATH**/ ?>