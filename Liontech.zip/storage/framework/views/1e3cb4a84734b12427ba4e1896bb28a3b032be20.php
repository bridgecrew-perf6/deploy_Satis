
<?php $__env->startSection('content'); ?>
          <nav class="navbar" >
            <div class="brand-title">TALLER DE INGENIERIA DE SOFTWARE</div>
            <a href="#" class="toggle-button">
              <span class="bar"></span>
              <span class="bar"></span>
              <span class="bar"></span>
            </a>
            <div class="navbar-links">
              <ul>
                <li><a href="<?php echo e(route('docente.inicioD')); ?>">Inicio</a></li>
                <li><a href="<?php echo e(route('docente.convocatoriasD')); ?>">Agregar convocatoria</a></li>
              <li><a href="<?php echo e(route('docente.avisosD')); ?>">Agregar Avisos</a></li>
                <li><a href="<?php echo e(url('/docente/lista')); ?>">Lista de empresas</a></li>
            
                <li><a href="<?php echo e(url('/docente/calendario')); ?>">Calendario</a></li>
                <li><a href="<?php echo e(route('auth.register')); ?>">Registrar estudiantes</a></li>
                <li><a href="<?php echo e(route('auth.logout')); ?>">Cerrar sesion</a></li>
                
              </ul>
            </div>
          </nav>
          <?php $__env->stopSection(); ?>
          <?php $__env->startSection('cuerpo'); ?> 

    <section>
        <div class=" mt-5 mb-5 ">
        <div class=" row cards2 d-flex justify-content-center">
          <div class="col-sm-6">
            <h2 class="textL"  for="empresas" class="form-label">Grupo Empresas</h2>
                <style>
                    table, th, td {
                        border: 2px solid black;
                        padding: 10px;
                       
                    }
                </style>
                <?php if(Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
                <?php endif; ?>
                <?php if(Session::get('fail')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('fail')); ?>

                </div>
                <?php endif; ?>
                <?php if(Session::get('fail2')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('fail2')); ?>

                </div>
                <?php endif; ?>
                <?php if(Session::get('fail3')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('fail3')); ?>

                </div>
                <?php endif; ?>
                <?php if(Session::get('fail4')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('fail4')); ?>

                </div>
                <?php endif; ?>
                <?php if(Session::get('fail5')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('fail5')); ?>

                </div>
                <?php endif; ?>
                <table name="empresas"  class="table tabla">
                    <thead class="tablaL">
                            <th class="text-center"><h4>Nombre corto</h4></th>  
                            <th class="text-center"><h4>Nombre Largo</h4></th>
                            <th class="text-center" colspan="9"><h4>Documentos</h4></th>
                    </thead>
                    
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                           
                            <td  align="center">
                                <h5> <?php echo e($item->nombreC); ?></h5>
                                
                            </td>
                        
                            <td>
                                <h5><?php echo e($item->nombreL); ?></h5>
                                                              
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('estudiante.parteA')); ?>" enctype="multipart/form-data">                               
                                <?php echo csrf_field(); ?>
                                <div class="d-flex justify-content-evenly" >
                                        
                                <div class=" " >
                                <button type="submit"  name="parteA" value="<?php echo e($item->id); ?>" class="btn btn-primary"  style="background-color: #215f88;">ParteA</button>
                            
                                </div>
                                </div>
                                </form>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('estudiante.parteB')); ?>" enctype="multipart/form-data">                               
                                <?php echo csrf_field(); ?>
                                <div class="d-flex justify-content-evenly" >
                                        
                                <div class=" " >
                                <button type="submit"  name="parteB" value="<?php echo e($item->id); ?>" class="btn btn-primary"  style="background-color: #215f88;">ParteB</button>
                            
                                </div>
                                </div>
                                </form>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('estudiante.trabajo')); ?>" enctype="multipart/form-data">                               
                                <?php echo csrf_field(); ?>
                                <div class="d-flex justify-content-evenly" >
                                        
                                <div class=" " >
                                <button type="submit"  name="trabajo" value="<?php echo e($item->id); ?>" class="btn btn-primary" style="background-color: #215f88;">Plan de trabajo</button>
                            
                                </div>
                                </div>
                                </form>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('estudiante.pagos')); ?>" enctype="multipart/form-data">                               
                                <?php echo csrf_field(); ?>
                                <div class="d-flex justify-content-evenly" >
                                        
                                <div class=" " >
                                <button type="submit"  name="pagos" value="<?php echo e($item->id); ?>" class="btn btn-primary" style="background-color: #215f88;">Plan de pagos</button>
                            
                                </div>
                                </div>
                                </form>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('docente.orden')); ?>" enctype="multipart/form-data">                               
                                <?php echo csrf_field(); ?>
                                <div class="d-flex justify-content-evenly" >
                                        
                                <div class=" " >
                                <button type="submit"  name="orden" value="<?php echo e($item->id); ?>" class="btn btn-primary" style="background-color: #215f88;">Crear orden de cambio</button>
                            
                                </div>
                                </div>
                                </form>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('estudiante.cambios')); ?>" enctype="multipart/form-data">                               
                                <?php echo csrf_field(); ?>
                                <div class="d-flex justify-content-evenly" >
                                        
                                <div class=" " >
                                <button type="submit"  name="cambios" value="<?php echo e($item->id); ?>" class="btn btn-primary" style="background-color: #215f88;">Ver orden de cambio</button>
                            
                                </div>
                                </div>
                                </form>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('docente.contrato')); ?>" enctype="multipart/form-data">                               
                                <?php echo csrf_field(); ?>
                                <div class="d-flex justify-content-evenly" >
                                        
                                <div class=" " >
                                <button type="submit"  name="id" value="<?php echo e($item->id); ?>" class="btn btn-primary" style="background-color: #215f88;">Generar contrato</button>
                            
                                </div>
                                </div>
                                </form>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('ver.contrato')); ?>" enctype="multipart/form-data">                               
                                <?php echo csrf_field(); ?>
                                <div class="d-flex justify-content-evenly" >
                                        
                                <div class=" " >
                                <button type="submit"  name="contrato" value="<?php echo e($item->id); ?>" class="btn btn-primary" style="background-color: #215f88;">Ver contrato</button>
                            
                                </div>
                                </div>
                                </form>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('docente.contratoD')); ?>" accept=".pdf" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>              
              
                                <div class="d-flex justify-content-evenly" style="margin-top:50px;">
                                <div>
                                    <input type="file" name="contrato"/>
                                    <span class="text-danger"><?php $__errorArgs = ['contrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>

         
                                <div class=" " >
                                <button type="submit"  name="id" value="<?php echo e($item->id); ?>" class="btn btn-primary" style="background-color: #215f88;">Actualizar contrato</button>
                           
                                </div>
                                </div>
                                </form>
                            </td>
                        </tr>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>
          </div>
            
        </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantillaD', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liontech2\Liontech\resources\views//docente/lista.blade.php ENDPATH**/ ?>