<?php $__env->startSection('cuerpo'); ?>
    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(@$usuario_empresa->emp && @$usuario_empresa->emp== $empresa->id || $LoggedUserInfo->tipo==2): ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Registro Plan de Pagos <?php echo e($empresa->nombreC); ?> </h2>
            </div>
            <?php if($LoggedUserInfo->tipo==3): ?>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('pagos.create')); ?>" title="Crear un pago"> <i class="fas fa-plus-circle"></i>
                    </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table table-bordered table-responsive-lg">
        <tr>
            <th>No</th>
            <th>Estado del Proyecto</th>
            <th>Entregable</th>
            <th>Fecha de Entrega</th>
            <th>Porcentaje</th>
            <th>Costo(BS.)</th>
            <?php if($LoggedUserInfo->tipo==3): ?>
            <th width="280px">Acción</th>
            <?php endif; ?>

        </tr>
        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if((@$usuario_empresa->emp==@$pago->id_empresa || $LoggedUserInfo->tipo==2) && @$pago->id_empresa == $empresa->id): ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($pago->estado_del_proyecto); ?></td>
                <td><?php echo e($pago->entregable); ?></td>
                <td><?php echo e($pago->fecha_de_entrega); ?></td>
                <td><?php echo e($pago->porcentaje); ?></td>
                <td><?php echo e($pago->costo); ?></td>
                <?php if($LoggedUserInfo->tipo==3): ?>
                <td>
                    
                    <form action="<?php echo e(route('pagos.destroy', $pago->id)); ?>" method="POST">

                        <a href="<?php echo e(route('pagos.show', $pago->id)); ?>" title="show">
                            <i class="fas fa-eye text-success  fa-lg"></i>
                        </a>

                        <a href="<?php echo e(route('pagos.edit', $pago->id)); ?>">
                            <i class="fas fa-edit  fa-lg"></i>

                        </a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit" title="delete" style="border: none; background-color:transparent;">
                            <i class="fas fa-trash fa-lg text-danger"></i>

                        </button>
                    </form>
                </td>
                <?php endif; ?>

            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/projects_Laravel/Liontech/resources/views/pagos/index.blade.php ENDPATH**/ ?>