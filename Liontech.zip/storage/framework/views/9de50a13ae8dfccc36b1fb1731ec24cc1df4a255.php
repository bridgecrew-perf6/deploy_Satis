
<?php $__env->startSection('content'); ?>
      <nav class="navbar ">
        <div class="brand-title">TALLER DE INGENIERIA DE SOFTWARE</div>
        <a href="#" class="toggle-button">
          <span class="bar"></span>
          <span class="bar"></span>
          <span class="bar"></span>
        </a>
        <div class="navbar-links">
          <ul>
            <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
            <li><a href="<?php echo e(url('/lista')); ?>">Lista de empresas</a></li>
            <li><a href="<?php echo e(url('/auth/login')); ?>">Iniciar Sesión</a></li>
            
          </ul>
        </div>
      </nav>
      <?php $__env->stopSection(); ?>
      <?php $__env->startSection('cuerpo'); ?>
    <section>
      
        <div class="container mt-5 mb-5 ">
        <div class=" row d-flex justify-content-between cards ">
         
          <table class="table tabla">
            <thead class="tablaL">
              
              <th class="text-center" border="1">Nombre corto</th>
              <th class="text-center" border="1">Nombre Largo</th>
            </thead>
            <tbody>
               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
              <tr>
              
          
                  <td align="center">
                      <?php echo e($item->nombreC); ?>

                      
                  </td>
                  <td align="center">
                      <?php echo e($item->nombreL); ?>                                
                  </td>
              </tr>
              
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
         
         
         
          
            
        </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/projects_Laravel/Liontech/resources/views/lista.blade.php ENDPATH**/ ?>